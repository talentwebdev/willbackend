####################################
Upgrading From Beta 1.0 to Final 1.2
####################################

To upgrade to Version 1.2 please replace the following directories with
the new versions:

.. note:: If you have any custom developed files in these folders please
	make copies of them first.

-  drivers
-  helpers
-  init
-  language
-  libraries
-  plugins
-  scaffolding

Please also replace your local copy of the user guide with the new
version.
